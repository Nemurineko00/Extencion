import Menu from "../componets/menu";

import "../styles/globals.css";

export default function App({ Component, pageProps }) {
  return (
    <>
      <Menu />
      <Component {...pageProps} />
    </>
  );
}